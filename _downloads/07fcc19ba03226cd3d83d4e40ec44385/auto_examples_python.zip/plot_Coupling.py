#!/usr/bin/env python
# coding: utf-8

# # Visualización del archivo de coupling 
# 
"""
Coupling figure - 2D Fault 
====================================
    Draw a GmtrFigure for the given lock model .
    """
# In[77]:


import pygmt
import numpy as np
#
file='../auxiliar/150_coupling.xyz'
file2='../auxiliar/locking_model.grd'

#
data=np.genfromtxt(file)
# data = data[data[:, 0].argsort()]
# Obtener índices para ordenar por las dos primeras columnas
sort_indices = np.lexsort((data[:, 1], data[:, 0]))

# Ordenar el array a utilizando los índices
data = data[sort_indices]
# Crear malla 2D utilizando meshgrid
# X, Y = np.meshgrid(np.unique(data[:, 0]), np.unique(data[:, 1]))
# # Z= np.reshape(data[:, 2], (np.unique(data[:, 0]).size, np.unique(data[:, 1]).size))
# Z=np.reshape(data[:, 2], (551,401))
# Reshape de la tercera columna para formar una matriz 2D
#
region=[-80,-69,-40,-27]
region2=[-76,-68,-36,-28]
grid=pygmt.xyz2grd(x=data[:,0],y=data[:,1],z=data[:,2],region=region2,spacing='0.01')
#
fig=pygmt.Figure()
fig.basemap(region=region,projection='M12c',frame='ag')
cmap=pygmt.makecpt(cmap='hot',reverse=True,series=[0, 1, 0.1],continuous=False)
fig.coast(shorelines=True, area_thresh=5000,land="gray")
fig.plot(x=[-75,-75],y=[-29,-36],fill='red',pen='2,red')
fig.text(x=-77,y=-33,text='1730 EQ',fill='yellow',font="15p,Helvetica-Bold,red")
fig.grdimage(grid=grid,cmap=cmap,nan_transparent=True)
fig.grdimage(grid=file2,cmap=cmap,nan_transparent=True)
fig.colorbar(
    cmap=cmap,
    # Colorbar positioned at map coordinates (g) longitude/latitude 0.3/8.7,
    # with a length/width (+w) of 4 cm by 0.5 cm, and plotted horizontally (+h)
    position="g-78/-39+w8c/0.5c+h",
    box='+ggray+pblack',
    frame=["x+lLocking degree"],
)
fig.show()

